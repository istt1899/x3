# Waze Стрелка 0.8.7

- Стабильность карточки: короткий GPS-сбой больше не снимает предупреждение — активная карточка держится до 5 с экстраполяцией по последней скорости и курсу (только для удержания, не для новых камер), после 5 с снимается с причиной `GPS_LOST`; на остановке (светофор, пробка) действующая карточка сохраняется. Минимальное время показа — 3 с: геометрический шум не мигает карточкой, проезд камеры снимает её по-прежнему сразу.
- Связь с cluster-render: постоянная сессия — пропадание карточки прячет слои, но не разрывает соединение; при разрыве переподключение с нарастающим интервалом 0,5 → 1 → 2 → 5 с, повторное создание слоёв и немедленная перерисовка активной карточки. В диагностике: `reconnects`, `lastDisconnectReason`, `lastReconnectAt`.
- Направление камеры: единое поле `capture` для всех источников (семантика — в `docs/camera-direction-0.8.7.md`): OSM `direction`/`camera:direction` (объектив, подтверждено), OSM enforcement relation (контролируемый поток; ровно одна пара from→to, иначе — весь перекрёсток и направление не выводится), OpenSpeedcam (азимут потока, не подтверждено документацией), Госавтоинспекция (текст «встречное/попутное» → в лицо/в спину/обе, подтверждено), записи владельца (опциональные `captureSide`/`facingDeg`). Покрытие на неизменённых источниках: facingKnown 20 → 185, captureSideKnown 0 → 152. Режим «рядом» предупреждает и о «в лицо», и о «в спину»; камера, достоверно смотрящая поперёк дороги, отклоняется (`DIRECTION`). На карточке HUD и приборки — «В лоб» / «Сзади» / «Две стороны» / «Напр. ?»; на странице камеры в HMI — направление, источник и статус подтверждения.
- Звук превышения: сценарий владельца — камера 60, GPS 90, порог +20 → сигнал. Лимит берётся из камеры, иначе из подтверждённого справочного; действует на дистанции контроля (по умолчанию 400 м). Повтор каждые 3/5/10 с или однократно; гистерезис снятия 3 км/ч; опциональный короткий сигнал при появлении камеры. Звук идёт через штатный гонг BMW: служба публикует `audioRequest`, HMI воспроизводит через `IGongCommand` и отвечает `audio-played`; до первого подтверждённого воспроизведения канал честно «не подтверждён» (кнопка «Проверить звук» на странице диагностики). Громкость и выбор типа гонга не добавлены — сигнатура SDK из облака не подтверждается.
- Настройки в приложении: звук вкл/выкл (по умолчанию вкл), порог +0…+40 (по умолчанию +20), дистанция контроля 100–700 м (по умолчанию 400), повтор (по умолчанию 5 с), сигнал появления камеры (по умолчанию выкл). Сохраняются в `settings.json` с дефолтами; старые файлы настроек читаются без правок.
- База данных: версия 2026.11.18.1 (производные поля capture; источники и байты снимков неизменны).
- Аудит апстрима (правило владельца): `robertn_waze_cluster` не менялся с 0.6.12 (признак ETA-карты перенесён в 0.8.6); `waze-on-cluster` 0.10.8–0.10.11 — внутренние изменения инструмента (Android Auto self-start, слот MapFeeds, тесты конфигурации), пользовательских функций приложению нет; обновление инструмента в общем каталоге — отдельное решение владельца.

# Waze Стрелка 0.8.6

- Автозапуск приложения при загрузке MGU (`mguAppStartType: autostart`): мост GPS BMW поднимается без ручного открытия приложения, камеры начинают предупреждать сразу после старта головного устройства. Действует при установке/обновлении через MGU Store из источника `istt1899/x3`; уже установленное приложение получит признак при обновлении на 0.8.6.
- Новый режим «рядом» для камер без дорожной зоны (467 из 486): предупреждение выводится на приборы и HUD при движении, когда камера в пределах настроенной дистанции в секторе 40° впереди; известное направление объектива дополнительно проверяется (камера должна смотреть на поток, допуск 45°). Снятие: камера позади (>100°), выход за дистанцию с гистерезисом точности, либо расстояние растёт три свежих измерения подряд. На стоянке новые предупреждения не включаются; уже показанное на светофоре сохраняется.
- Камеры владельца (`reported-cameras.json`) предупреждают в режиме «рядом» независимо от переключателей типов: у собственной записи нет подтверждённого типа.
- Диагностика: в статусе службы — число «рядом»-кандидатов в радиусе, причина отказа ближайшего кандидата (позади / вне сектора / направление объектива / стоянка / дистанция), русская причина состояния GPS-моста (не запущен, подписка не подтверждена, прокси не отвечает и т.д.); страница «Камера» диагностики показывает эти поля.
- Приоритет не изменился: подтверждённое дорожное предупреждение вытесняет «рядом»; логика 19 дорожных зон и GPS-фильтры качества не тронуты.
- Перенесено из апстрима Waze on Cluster 0.6.9–0.6.12: устаревший патч определяется также по карте кластера без карточки времени прибытия (`mapurl: no-eta`); полная функция ETA-карты требует `waze-on-cluster ≥ 0.10.x` и активируется отдельным обновлением инструмента в каталоге. Остальные новшества релизов 0.6.9–0.6.12 (safe area, выгрузка диагностики patchd, переименование) — инструментальные, на стороне waze-on-cluster/cluster-render.

# Waze Стрелка 0.8.5

- Исправлена регрессия запасного режима BMW: когда GNSS заглушен, `Positioning.currentLocation` может не содержать явные `speedKmh`/курс/точность. Теперь скорость и курс вычисляются из последовательных свежих позиций навигации; для стоянки требуется три согласованные позиции за 2 секунды.
- Тест изображения на стоянке снова получает свежую скорость `0 км/ч` от BMW navigation fallback и не останавливается на `STATIONARY_UNKNOWN`. Тест в движении по-прежнему запрещён.
- Для дорожных предупреждений при отсутствии числовой точности используется только подтверждённая BMW дорожная привязка `ON_ROAD`; явная точность хуже 15 м по-прежнему отклоняется, а BMW NMEA/GNSS сохраняет приоритет.
- Диагностика явно показывает источник точности: число в метрах или «дорожная привязка BMW».

# Waze Стрелка 0.8.4

- Из апстрима Waze on Cluster перенесены: режим «Показывать на: Выкл.», собственные настройки карты для профиля водителя и удержание карты HUD поверх всплывающих окон BMW. Для полного набора требуются `waze-on-cluster 0.9.14` и `cluster-render 0.5.9`; с более старыми версиями новые пункты остаются серыми или недоступными.
- Улучшена стабильность камерных предупреждений: новый подъём по-прежнему требует точности 15 м, но уже подтверждённое дорожное предупреждение не мигает при кратких просадках точности до 30 м. Уход с дороги, разворот курса, устаревание UTC и пройденная камера по-прежнему снимают предупреждение немедленно.

# Waze Стрелка 0.8.3

- При глушении GNSS добавлен запасной контур штатной навигации BMW через тот же read-only `Positioning.currentLocation`. Он включается только при `ON_ROAD`, явных координатах, скорости, курсе и точности в метрах не хуже 15 м.
- Подтверждённый BMW NMEA/GNSS сохраняет безусловный приоритет; навигация не смешивается с частями NMEA и имеет возраст не более 3 секунд. Ответ без точности остаётся диагностическим и не включает предупреждения.
- IPC `vehicle-context` расширен опциональным полем `navigation`; старые версии приложения и сервиса остаются совместимы. В диагностике GPS добавлены состояние, число принятых и отклонённых навигационных позиций.

# Waze Стрелка 0.5.1

- Исправлено скрытие известного ограничения скорости в режиме «Рядом»: значение из базы отображается с пометкой «Рядом • база».
- На Плеханова/Суворова 60 доступно для четырёх OSM-объектов и официальной записи через ранее проверенные связи рубежа. Источники доступны в диагностике.
- Справочный лимит не включает сигнал превышения без подтверждения дороги; конфликтующие и неизвестные значения не заменяются городским 60.
- База 2026.11.7.1 и профили калибровки сохранены. BMW Speed Limit Information ещё не считывается.

# Waze Стрелка 0.5.0

- Официальный перечень ГИБДД Калужской области: 152 прошедшие проверку позиции, виды нарушений и отдельное происхождение сведений.
- Рабочая база: 308 записей источников, без заявления о числе физических камер или полном покрытии.
- Проверка источников, карантин координат и канал обновления v2 с резервной копией и откатом.
- Автоматическая установка новой базы из пакета; повреждение дополнительного источника явно диагностируется без ложного повышения версии.
- Отдельные профили калибровки HUD и приборов версии 0.4.2 сохранены.

# Waze Стрелка 0.4.2

- На первой странице «Камеры»: отдельные профили уведомлений для HUD и приборной панели.
- Закреплённый тест, стрелки положения, размер, яркость и прозрачность с немедленным предпросмотром.
- Автосохранение, завершение с подтверждением записи, независимый сброс выбранного экрана.
- Тест снимается при движении, устаревшей скорости и отключении выбранного выхода.
- Реальные предупреждения используют те же сохранённые профили; настройки карты не меняются.

# Waze Стрелка 0.4.1

- Исправлены регистрация сетевого UID сервиса, ограниченное восстановление GPS/NAV/GONG и watchdog команд по точному requestId до терминального ответа.
- Полные результаты команд доступны перелистыванием; renderer сообщает состояние соединения и честное отсутствие версии в протоколе.
- Восстановление базы показывает причину и источник; зоны проверяются относительно камеры, rename сопровождается fsync каталога там, где это поддерживается.
- Добавлены контроль телефона, канонические LF-артефакты и проверки воспроизводимости сборки.
- На автомобиле этот патч пока не проверен; канал штатных камер BMW и воспроизведение gong не включены.

Shared action policy and immediate command feedback; stationary renderer tests independent of position accuracy; adaptive compact multi-type cards; six-page frozen diagnostics with explicit local RAM export; optional read-only BMW street bridge; relation-aware database with 156 records and independent atomic updates/rollback. Native sound discovery does not enable unverified gong playback. On-car display and native integration remain to be verified.

# Waze Стрелка 0.3.1

Preserve complete GNSS measurements across staggered RMC/GGA/GST epochs, keep stopped-approach notices, display typed/model camera cards and explicit proximity notices. Dedicated detailed diagnostics with frozen snapshots and parked-only five-second display test. Alert layers contend for their enabled targets without being exclusive. Camera metadata retains original OSM enforcement/description tags.

# Waze Стрелка 0.3.0

Read-only BMW SatellitePositioning NMEA bridge, background GPS activity after the first manual launch, separate native decoder and visible reception counters. No guessed CAN units or HDOP-to-metres conversion. GPS stream availability on the target car still needs verification.

# Upstream Waze on Cluster changelog

# Changelog

## 0.6.0

The map on the HUD, contributed by eroobeeroo and wesleyredhat. Show on, a
drop-down in General, chooses where the map shows: Cluster (the default),
HUD (experimental) or Cluster and HUD (experimental); with both the HUD uses
up to half the upload bandwidth, only what it needs. With the map not on
the cluster, `Cluster map: Off` and the Hide BMW's turn box checkbox is
greyed. A HUD section: `HUD map: …`, the Size slider (5 %
a step from 30 % to 85 %) and `Position: …` with Move left, Move right, Move
up, Move down and Centre, greyed while the HUD is off, and while the
cluster renderer keeps it off after errors (`HUD map: Disabled after
errors`). The settings take effect at once and are kept for the next
start, in a file of their own that waze-on-cluster 0.8 does not read, so
going back to it keeps working. These rows are in the head unit's display language, as is the rest
of the page. Requires waze-on-cluster 0.9.0.

The page's sections: General first, then HUD, CarPlay, Android Auto.
Restart head unit and its Restart row are the page's last rows, so nothing
above them moves when they show.

CarPlay's section shows `CarPlay Wi-Fi: 5 GHz` or `CarPlay Wi-Fi: 2.4 GHz`
while CarPlay runs over Wi-Fi and waze-on-cluster knows the band. On 2.4
GHz a line under it says `Audio may cut out. On your iPhone, turn Wi-Fi off
and on.` Saved logs include CarPlay's Wi-Fi band, the Wi-Fi interfaces'
counters and the kernel's Wi-Fi connection lines.

## 0.5.7

The map's capture starts at boot after the head unit's media bus is up,
ordered after BMW's own media services and never holding any of them up.
Requires waze-on-cluster 0.8.6.

## 0.5.6

When boot recovery removed a patch because the head unit kept restarting
with it, its Status row reads `Removed — head unit kept restarting`, in the
display language, also with part of the patch left, until its Patch button
applies the patch again. On a head unit that refuses the tool, `Not
supported on this car` comes first. Requires waze-on-cluster 0.8.5.

## 0.5.5

On a HIGH F car where waze-on-cluster 0.8.2 removed the patch at boot, the
update puts it back by itself: the app shows `Status: Patched after
restart`, and the map returns at the next head-unit start or drive.
Requires waze-on-cluster 0.8.4.

## 0.5.4

HIGH F head units are supported again, as every variant is; only a head
unit whose variant cannot be read shows `Not supported on this car`.
Requires waze-on-cluster 0.8.3.

## 0.5.3

Every word on both pages, and the tile's name, in the head unit's display
language: each language the iDrive 7 HMI offers, English where a language
has no translation. A change of the display language shows at once. Values
from the tools (reasons, addresses, numbers) are shown as they are.

## 0.5.2

On a head unit that refuses the tool (HIGH F, or a variant it cannot
read), CarPlay and Android Auto both read `Status: Not supported on this
car`, also while a patch from before is on disk or an apply of it waits
for the next start, which boot recovery turns into a restore; Restart head
unit stays offered while one is needed. Neither Patch button, Zoom out,
Zoom in nor the turn card checkbox is offered there; Remove patch stays.
`Cluster map: Unavailable` while the tool reports itself unsupported, and
the Hide BMW's turn box row is greyed. Requires waze-on-cluster 0.8.2.

## 0.5.1

The main page in three sections under header rows. CarPlay and Android Auto
have the same rows with the same words: `Status: …`, Patch and Remove
patch; Android Auto adds Zoom (`Zoom: 170 dpi`), Zoom out, Zoom in and the
Hide phone's turn card checkbox. General: `Cluster map: …` (the map the
shared render draws for either phone), the Hide BMW's turn box checkbox,
Logs, and Restart head unit with its `Restart: …` row. Info rows read
`Name: Value`; on/off settings are `Hide …` checkboxes; `(after restart)`
marks a value that waits for the next head-unit start. Both Status rows
use one set of words (`Patched`, `Not patched`, `Patching…`, `Patched after
restart`, `Failed`, `Not supported on this car`, …). Rows stay in place and
are greyed when they cannot act; while any change runs, every change in
both sections is greyed. Restart head unit, the last row, shows only while
a change waits for a restart; its row says when it failed, why, and when
the 10-minute limit allows the next. The log lines and the setup line are
off the main page; Start capture is on the Logs page. Restart head unit
asks the Node State Manager for a normal restart. Requires
waze-on-cluster 0.8.1.

## 0.5.0

Android Auto next to CarPlay: a line with its state (patched and its
density, off, pending, not supported on this car, untested aapd build),
Enable Android Auto, Disable Android Auto, Zoom out and Zoom in for the
density, and Hide turn card / Show turn card. Restart head unit also
activates a pending Android Auto change. Requires waze-on-cluster 0.8.0.

## 0.4.4

Hide BMW turn box: a checkbox on the main page. Ticked (the default), BMW's
own CarPlay turn-by-turn box on the cluster stays hidden while the Waze map
shows; unticked, it shows. The choice takes effect at once and is kept
across restarts and updates. While the cluster renderer keeps the box shown
(its mapping guard), the checkbox is greyed and labelled unavailable.
Requires waze-on-cluster 0.7.13.

## 0.4.3

A Logs page: Save logs saves an archive of the tools' logs, the journal
lines they keep and their status, and a phone on the car's Wi-Fi hotspot
downloads the saved archives from the address the page shows, as text and as
a QR code. Requires waze-on-cluster 0.7.11.

## 0.4.1

While CarPlay's stream is live but shows no map, the status says why, from
waze-on-cluster 0.7.2 on: "Stream lost — reconnect CarPlay", or "Stream
lost — restarting CarPlay" where the tool restarts CarPlay itself.

## 0.4.0

The page says to set Instrument cluster > Central display area to Map view:
the Waze map replaces the stock map while CarPlay streams it, and the stock
map is back when the stream ends or freezes. A frozen stream shows "Map
frozen — reconnect CarPlay". Requires waze-on-cluster 0.6.0.

## 0.3.1

The page says to set Instrument cluster > Central display area to Off: with
Map view, Route preview or Assisted Driving View there, the cluster shows its
own content in the centre instead of the map.

## 0.3.0

Installing the app from the Store installs the Waze tool and the cluster
renderer too. The tool writes the CarPlay patch as it installs, without
restarting CarPlay; until the next head-unit start the app shows "Patch
pending — reboot to activate". Enable map appears only when the patch is
off, unknown or out of date, Disable map only when it is on. When the install
leaves CarPlay unpatched (an unknown CarPlay build, or another tool starting
CarPlay), the app says why and offers Enable map. The Store can remove the
app and then the Waze tool, which restores CarPlay.

## 0.2.11

When a patch change waits for the next head-unit start, the app says so and
offers a Restart head unit button. A boot recovery service restores the
original CarPlay binary after repeated failed starts with the patch.

## 0.2.10

The map appears on the cluster by itself when CarPlay streams it and goes
away when the stream stops; there is no Show or Stop button. Disable map
turns the feature off.

## 0.2.9

Enable map sets the area where the phone places its guidance, so Waze's
next-turn banner stays visible between the gauges. Units patched with a
full-frame area are prompted to update.

## 0.2.8

The map is drawn in the cluster's native map area (1088x480), under the
gauges. Units patched at another size are prompted to Enable map again.

## 0.2.7

Enable map applies a single patch configuration, including the size the
phone renders the map at. Units on another panel setting are prompted to
update.

## 0.2.6

Enable map uses a single capture path; the capture mode row is removed.
Capture logs has its own button.

## 0.2.5

The status line reads "Patch state unknown — enable the map" until the patch
daemon reports, so the page opens cleanly.

## 0.2.4

After Enable map, the cluster stream starts with the CarPlay session. A patch
waiting for the next head-unit start reads "Patch pending — …".

## 0.2.3

The diagnostic capture window is up to 5 minutes.

## 0.2.2

Capture mode offers a UDP stream sink.

## 0.2.1

Capture logs: a bounded DLT capture, with its status and an early stop.

## 0.2.0

A capture mode choice for Enable map.

## 0.1.0

First release: a page to apply and revert the CarPlay patch, show and stop
the map on the cluster, and read both tools' logs.
