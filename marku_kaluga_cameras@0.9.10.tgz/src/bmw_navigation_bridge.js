// SPDX-License-Identifier: GPL-3.0-or-later
'use strict';
// Optional read-only native capabilities. A field must exist in the installed
// SDK and be available on this car; no CAN scale, street or audio route guessed.
const EventEmitter = require('events');
const NAV = 'de.bmw.infotainment.navigation.positioning.Positioning';
const GONG = 'de.bmw.infotainment.gp.gongplayer.IGPCommand';
function streetOf(value) {
    if (!value || (value.status !== 'ON_ROAD' && value.status !== 1)) return null;
    const text=value.textDescription, list=text && text.textDescriptorList;
    let speech=null;
    if(list instanceof Map)speech=list.get('STREET')||list.get(14)||list.get('14');
    else if(list && !Array.isArray(list) && typeof list==='object')speech=list.STREET||list['14'];
    else if(Array.isArray(list)){
        const entry=list.find(e=>e&&(e.key==='STREET'||e.key===14||e.key==='14'));
        speech=entry&&entry.value;
    }
    if(!speech || typeof speech.orthography!=='string')return null;
    const name=speech.orthography.trim();
    return name && name.length<=96 && Buffer.byteLength(name,'utf8')<=240 && !/[\x00-\x1f\x7f]/.test(name)?name:null;
}
function numberAt(value, names) {
    if (!value || typeof value !== 'object') return null;
    for (const name of names) {
        const candidate = value[name];
        if (typeof candidate === 'number' && isFinite(candidate)) return candidate;
        if (candidate && typeof candidate === 'object' && typeof candidate.value === 'number' && isFinite(candidate.value)) return candidate.value;
    }
    return null;
}
function stringAt(value, names) {
    if (!value || typeof value !== 'object') return null;
    for (const name of names) {
        const candidate = value[name];
        if (typeof candidate === 'string' && candidate) return candidate;
        if (candidate && typeof candidate === 'object' && typeof candidate.unit === 'string' && candidate.unit) return candidate.unit;
    }
    return null;
}
function firstObject(value, names) {
    if (!value || typeof value !== 'object') return null;
    for (const name of names) {
        const candidate = value[name];
        if (candidate && typeof candidate === 'object' && !Array.isArray(candidate)) return candidate;
    }
    return null;
}
function explicitSpeedOf(value) {
    if (!value || typeof value !== 'object') return null;
    const direct = numberAt(value, ['speedKmh', 'speedKph', 'speedKmH']);
    if (direct !== null) return direct >= 0 ? direct : null;
    const speed = numberAt(value, ['speed', 'vehicleSpeed', 'motionSpeed']);
    if (speed === null || speed < 0) return null;
    const unit = stringAt(value, ['speedUnit', 'speedUnits', 'velocityUnit', 'vehicleSpeedUnit', 'speed']);
    if (typeof unit !== 'string') return null;
    const normalized = unit.toLowerCase().replace(/[\s_]/g, '');
    if (['km/h', 'kmh', 'kph', 'kilometresperhour', 'kilometersperhour'].indexOf(normalized) >= 0) return speed;
    if (['m/s', 'mps', 'metrespersecond', 'meterspersecond'].indexOf(normalized) >= 0) return speed * 3.6;
    return null;
}
function explicitTimeOf(value) {
    if (!value || typeof value !== 'object') return null;
    const millis = numberAt(value, ['timeMs', 'timestampMs', 'utcMs', 'positionTimeMs']);
    if (millis !== null) return millis;
    const text = value.timestamp || value.time || value.utc;
    if (typeof text !== 'string') return null;
    const parsed = Date.parse(text);
    return isFinite(parsed) ? parsed : null;
}
function distanceM(a, b) {
    const rad = Math.PI / 180, x = (b.lon - a.lon) * Math.cos((a.lat + b.lat) * rad / 2), y = b.lat - a.lat;
    return Math.sqrt(x * x + y * y) * rad * 6371008.8;
}
function bearingDeg(a, b) {
    const rad = Math.PI / 180, lat1 = a.lat * rad, lat2 = b.lat * rad, dLon = (b.lon - a.lon) * rad;
    const y = Math.sin(dLon) * Math.cos(lat2), x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}
class NavigationMotion {
    constructor() { this.samples = []; }
    reset() { this.samples = []; }
    observe(fix, now) {
        if (!fix) { this.reset(); return fix; }
        const sample = { lat: fix.lat, lon: fix.lon, timeMs: fix.timeOrigin === 'source' ? fix.timeMs : now };
        const previous = this.samples[this.samples.length - 1];
        if (previous && sample.timeMs <= previous.timeMs) this.samples = [];
        this.samples.push(sample);
        this.samples = this.samples.filter(item => sample.timeMs - item.timeMs <= 5000);
        let speed = Number.isFinite(fix.speedKmh) ? fix.speedKmh : null;
        let heading = Number.isFinite(fix.headingDeg) ? fix.headingDeg : null;
        let derived = false;
        if (speed === null) {
            speed = this.speedFromSamples();
            derived = speed !== null;
        }
        if (heading === null && Number.isFinite(speed) && speed >= 3) {
            heading = this.headingFromSamples();
            derived = derived || heading !== null;
        }
        return Object.assign({}, fix, { speedKmh: speed, headingDeg: heading, motionDerived: derived });
    }
    speedFromSamples() {
        if (this.samples.length < 2) return null;
        const first = this.samples[0], last = this.samples[this.samples.length - 1], elapsed = last.timeMs - first.timeMs;
        if (elapsed < 900) return null;
        let farthest = 0;
        this.samples.forEach(item => { farthest = Math.max(farthest, distanceM(first, item)); });
        if (this.samples.length >= 3 && elapsed >= 2000 && farthest <= 2) return 0;
        const moved = distanceM(first, last);
        if (moved < 3) return null;
        const speed = moved / (elapsed / 1000) * 3.6;
        if (speed > 250) { this.samples = [last]; return null; }
        return speed;
    }
    headingFromSamples() {
        if (this.samples.length < 2) return null;
        const first = this.samples[0], last = this.samples[this.samples.length - 1];
        return distanceM(first, last) >= 3 ? bearingDeg(first, last) : null;
    }
}
function navigationFixOf(value, now) {
    const unavailable = reason => ({ state: 'unavailable', reason, observedAtMs: now, fix: null });
    const partial = reason => ({ state: 'partial', reason, observedAtMs: now, fix: null });
    if (!value || typeof value !== 'object' || Array.isArray(value)) return unavailable('BMW не передала объект текущей позиции навигации');
    if (value.status !== 'ON_ROAD' && value.status !== 1) return unavailable('Штатная навигация не подтвердила состояние ON_ROAD');
    const position = firstObject(value, ['position', 'geoPosition', 'location', 'currentPosition', 'coordinate']);
    const motion = firstObject(value, ['motion', 'dynamics', 'vehicleMotion']);
    const roots = [value, position, motion].filter(Boolean);
    const latitude = roots.reduce((found, item) => found !== null ? found : numberAt(item, ['latitude', 'lat']), null);
    const longitude = roots.reduce((found, item) => found !== null ? found : numberAt(item, ['longitude', 'lon', 'lng']), null);
    if (latitude === null || longitude === null || Math.abs(latitude) > 90 || Math.abs(longitude) > 180)
        return unavailable('В ответе навигации нет явных координат в градусах');
    const accuracy = roots.reduce((found, item) => found !== null ? found : numberAt(item,
        ['horizontalAccuracyM', 'accuracyM', 'positionAccuracyM', 'uncertaintyM', 'horizontalUncertaintyM',
            'horizontalAccuracy', 'positionAccuracy', 'accuracy']), null);
    if (accuracy !== null && accuracy <= 0) return partial('Навигация BMW дала недопустимую точность; предупреждения не разрешены');
    if (accuracy > 15) return partial('Точность навигации BMW хуже 15 м; предупреждения не разрешены');
    const heading = roots.reduce((found, item) => found !== null ? found : numberAt(item,
        ['headingDeg', 'headingDegrees', 'heading', 'courseDeg', 'course', 'bearingDeg', 'bearing']), null);
    if (heading !== null && (heading < 0 || heading >= 360)) return partial('Курс навигации BMW вне диапазона 0–360°');
    const speed = roots.reduce((found, item) => found !== null ? found : explicitSpeedOf(item), null);
    const timeMs = explicitTimeOf(value);
    return {
        state: 'ready', reason: accuracy === null ? 'Точность BMW не сообщается; используется дорожная привязка ON_ROAD' : null, observedAtMs: now,
        fix: { lat: latitude, lon: longitude, accuracyM: accuracy, accuracySource: accuracy === null ? 'bmw-road-match' : 'explicit',
            speedKmh: speed, headingDeg: heading,
            timeMs: timeMs === null ? now : timeMs, timeOrigin: timeMs === null ? 'receipt' : 'source' }
    };
}
class BmwNavigationBridge extends EventEmitter {
    constructor(options){
        super();const o=options||{};this.builders=o.builders;this.control=o.control;
        this.now=o.now||Date.now;this.timeoutMs=o.timeoutMs||8000;this.pollMs=o.pollMs||1000;
        this.retryMs=o.retryMs||10000;this.retryMaxMs=Math.max(this.retryMs,o.retryMaxMs||60000);
        this.running=false;this.generation=0;this.proxy=null;this.timer=null;this.pollPending=false;this.pollGeneration=0;this.subscribed=false;
        this.channels={nav:{active:null,attempts:new Set(),retry:null,failures:0},audio:{active:null,attempts:new Set(),retry:null,failures:0}};
        this.maxAttempts=3;this.pendingGetter=null;
        this.street={name:null,source:'BMW',state:'unavailable',reason:'Название улицы BMW ещё не получено',observedAtMs:null};
        this.navigation={state:'unavailable',reason:'Позиция навигации BMW ещё не получена',observedAtMs:null,fix:null};
        this.motion=new NavigationMotion();
        this.audio={available:false,state:'unverified',reason:'Безопасный звуковой канал BMW не подтверждён'};
        this.lastLinkUp=false;this.controlChanged=()=>{const up=this.control&&this.control.link==='up';if(up&&!this.lastLinkUp)this.lastPublished='';this.lastLinkUp=up;this.publish();};
        if(this.control && this.control.on)this.control.on('change',this.controlChanged);
        this.lastPublished='';
    }
    publish(){
        if(!this.running||!this.control||this.control.link!=='up')return;
        const msg={cmd:'vehicle-context',street:this.street,audio:this.audio,navigation:this.navigation};
        const signature=JSON.stringify(msg);if(signature===this.lastPublished)return;
        const sock=this.control.sock,pending=sock&&(typeof sock.writableLength==='number'?sock.writableLength:sock.bufferSize);
        if(typeof pending==='number'&&pending>16384)return;
        try{if(this.control.send(msg))this.lastPublished=signature;}catch(ignored){}
    }
    status(){return {street:Object.assign({},this.street),navigation:Object.assign({},this.navigation,{fix:this.navigation.fix&&Object.assign({},this.navigation.fix)}),audio:Object.assign({},this.audio)};}
    build(iface,instance,active){
        if(!this.builders)return Promise.reject(new Error('BUILDER_UNAVAILABLE'));
        if(typeof this.builders.buildAndInitTypedProxy==='function')return this.builders.buildAndInitTypedProxy(iface,instance,{timeoutMs:this.timeoutMs});
        let proxy;
        return Promise.resolve(this.builders.buildTypedProxy(iface,instance)).then(p=>{if(!active())return;proxy=p;return p.init();})
            .then(()=>active()?proxy.waitUntilAvailable():null).then(()=>active()?proxy:null);
    }
    current(generation){return this.running&&generation===this.generation;}
    active(kind,attempt){return this.current(attempt.generation)&&this.channels[kind].active===attempt;}
    unavailable(kind,reason){
        if(kind==='nav'){
            this.street={name:null,source:'BMW',state:'unavailable',reason,observedAtMs:null};
            this.navigation={state:'unavailable',reason,observedAtMs:null,fix:null};
        }else this.audio={available:false,state:'unavailable',reason};
        this.publish();
    }
    schedule(kind,generation){
        const channel=this.channels[kind];
        if(!this.current(generation)||channel.retry||channel.active)return;
        const delay=Math.min(this.retryMaxMs,this.retryMs*Math.pow(2,Math.min(channel.failures++,10)));
        channel.retry=setTimeout(()=>{channel.retry=null;this.connect(kind,generation);},delay);
    }
    connect(kind,generation){
        const channel=this.channels[kind];
        if(!this.current(generation)||channel.active)return;
        if(channel.attempts.size>=this.maxAttempts){
            this.unavailable(kind,kind==='nav'?'Лимит незавершённых запросов BMW; требуется перезапуск приложения':'Лимит незавершённых звуковых запросов BMW; требуется перезапуск приложения');
            return;
        }
        const attempt={generation,retained:false,deadline:null};channel.active=attempt;channel.attempts.add(attempt);
        const active=()=>this.active(kind,attempt);
        const settle=()=>{
            if(!attempt.retained)channel.attempts.delete(attempt);
            if(!active()&&this.running&&channel.attempts.size<this.maxAttempts)this.schedule(kind,this.generation);
        };
        attempt.deadline=setTimeout(()=>{
            if(!active())return;channel.active=null;
            this.unavailable(kind,kind==='nav'?'Интерфейс или подписка улицы BMW не ответили; повторное подключение':'Проверка звукового сервиса BMW не получила ответа; повторное подключение');
            this.schedule(kind,generation);
        },this.timeoutMs);
        Promise.resolve().then(()=>active()?this.build(kind==='nav'?NAV:GONG,kind==='nav'?'Main_Instance':'1',active):null).then(proxy=>{
            if(!active())return;
            if(kind==='nav'){
                if(!proxy||!proxy.currentLocation||typeof proxy.currentLocation.subscribe!=='function'||typeof proxy.currentLocation.getValue!=='function')throw new Error('CURRENT_LOCATION_UNAVAILABLE');
                // No verified SDK unsubscribe exists. Keep this slot even if
                // subscribe hangs: retired callbacks cannot publish, and at
                // most three native registrations can exist in this process.
                attempt.retained=true;
                return Promise.resolve(proxy.currentLocation.subscribe(value=>{if(active())this.receive(value,generation);})).then(()=>proxy);
            }
            // Listing supported sound samples is read-only. Never requestGong:
            // discovery does not establish ownership or safe system priority.
            if(!proxy||typeof proxy.getAllSampleSets!=='function')throw new Error('GONG_PROBE_UNAVAILABLE');
            return proxy.getAllSampleSets();
        }).then(result=>{
            settle();if(!active())return;clearTimeout(attempt.deadline);channel.failures=0;
            if(kind==='nav'){
                this.proxy=result;this.subscribed=true;this.poll(generation);
                this.timer=setInterval(()=>this.poll(generation),this.pollMs);
            }else{
                const samples=result&&result.listSampleNames;
                this.audio={available:false,state:'detected',reason:'Сервис звука найден; параметры безопасного уведомления ещё не подтверждены',sampleSetCount:Array.isArray(samples)?Math.min(samples.length,50):null};this.publish();
            }
        }).catch(()=>{
            settle();if(!active())return;clearTimeout(attempt.deadline);channel.active=null;
            this.unavailable(kind,kind==='nav'?'Чтение улицы BMW временно недоступно; повторное подключение':'Безопасный звуковой канал BMW недоступен; радио не переключается');
            this.schedule(kind,generation);
        });
    }
    start(){
        if(this.running)return;this.running=true;this.subscribed=false;this.pollPending=false;const generation=++this.generation;
        this.street={name:null,source:'BMW',state:'unavailable',reason:'Название улицы BMW ещё не получено',observedAtMs:null};
        this.navigation={state:'unavailable',reason:'Позиция навигации BMW ещё не получена',observedAtMs:null,fix:null};
        this.motion.reset();
        this.audio={available:false,state:'unverified',reason:'Безопасный звуковой канал BMW не подтверждён'};
        this.lastPublished='';this.publish();
        this.connect('nav',generation);this.connect('audio',generation);
    }
    poll(generation){
        if(!this.current(generation)||!this.proxy||this.pendingGetter)return;
        const proxy=this.proxy;
        this.pollPending=true;const request=++this.pollGeneration;let expired=false;
        const pending={};this.pendingGetter=pending;
        this.pollDeadline=setTimeout(()=>{expired=true;if(this.current(generation)&&this.pollGeneration===request){
            this.street={name:null,source:'BMW',state:'unavailable',reason:'Чтение улицы BMW задержано; ожидаются живые уведомления',observedAtMs:null};
            this.navigation={state:'unavailable',reason:'Чтение позиции навигации BMW задержано; ожидаются живые уведомления',observedAtMs:null,fix:null};this.publish();
        }},this.timeoutMs);
        // Keep one outstanding SDK getter. A timeout is visible but does not
        // create an unbounded queue of uncancellable native requests. Live
        // subscribed updates can still deliver the street and the fallback
        // navigation position while the getter is pending.
        Promise.resolve().then(()=>this.current(generation)&&this.pollGeneration===request?proxy.currentLocation.getValue():null).then(value=>{if(!expired&&this.current(generation)&&this.pollGeneration===request)this.receive(value,generation);},()=>{
            if(this.current(generation)&&this.pollGeneration===request){
                this.street={name:null,source:'BMW',state:'unavailable',reason:'Не удалось прочитать текущую улицу BMW',observedAtMs:null};
                this.navigation={state:'unavailable',reason:'Не удалось прочитать позицию навигации BMW',observedAtMs:null,fix:null};this.publish();}
        }).then(()=>{if(this.pendingGetter===pending)this.pendingGetter=null;if(this.current(generation)&&this.pollGeneration===request){clearTimeout(this.pollDeadline);this.pollPending=false;}});
    }
    receive(value,generation){
        if(!this.current(generation))return;
        const name=streetOf(value), navigation=navigationFixOf(value,this.now());
        if(navigation.fix)navigation.fix=this.motion.observe(navigation.fix,this.now());
        else this.motion.reset();
        this.street={name,source:'BMW',state:name?'ready':'unavailable',reason:name?null:'BMW не передала подтверждённое название текущей улицы',observedAtMs:this.now()};
        this.navigation=navigation;
        this.publish();this.emit('change');
    }
    stop(){
        if(!this.running)return;this.running=false;this.generation++;
        Object.keys(this.channels).forEach(kind=>{const channel=this.channels[kind];clearTimeout(channel.retry);channel.retry=null;channel.attempts.forEach(attempt=>clearTimeout(attempt.deadline));channel.active=null;});
        clearTimeout(this.pollDeadline);clearInterval(this.timer);this.timer=null;this.proxy=null;this.pollPending=false;this.subscribed=false;this.pollGeneration++;
        this.navigation={state:'unavailable',reason:'Чтение позиции навигации BMW остановлено',observedAtMs:null,fix:null};
        this.motion.reset();
        // Pending uncancellable getters/registrations retain their bounded
        // slots across start/stop. Late callbacks cannot publish cached data.
    }
}
module.exports={BmwNavigationBridge,NavigationMotion,streetOf,navigationFixOf,NAV,GONG};
